import math, random

# ---------- shared design tokens ----------
BG       = "#0B0E13"   # panel background (near-black navy)
PANEL    = "#0E1420"   # inner plot bg
BORDER   = "#1E2A3A"   # panel border
GRID     = "#18212E"   # faint gridlines
GRID2    = "#131A24"
AXIS     = "#5B6673"   # muted axis text
TICK     = "#2A3644"   # tick marks
CYAN     = "#3FB6F0"   # primary series
AMBER    = "#F5A623"   # accent / last-price tag / 2nd series
GREEN    = "#22A783"   # up candle
RED      = "#E5484D"   # down candle
MUTED    = "#39465A"   # skeleton toolbar
W, H = 800, 500
MONO = "ui-monospace,'SF Mono',Menlo,Consolas,monospace"
SANS = "'Inter','Segoe UI',system-ui,sans-serif"

def catmull_to_path(pts):
    """Smooth path through pts via Catmull-Rom -> cubic bezier."""
    if len(pts) < 3:
        return "M " + " L ".join(f"{x:.1f},{y:.1f}" for x,y in pts)
    d = f"M {pts[0][0]:.1f},{pts[0][1]:.1f} "
    for i in range(len(pts)-1):
        p0 = pts[i-1] if i>0 else pts[0]
        p1 = pts[i]
        p2 = pts[i+1]
        p3 = pts[i+2] if i+2 < len(pts) else pts[-1]
        c1x = p1[0] + (p2[0]-p0[0])/6.0
        c1y = p1[1] + (p2[1]-p0[1])/6.0
        c2x = p2[0] - (p3[0]-p1[0])/6.0
        c2y = p2[1] - (p3[1]-p1[1])/6.0
        d += f"C {c1x:.1f},{c1y:.1f} {c2x:.1f},{c2y:.1f} {p2[0]:.1f},{p2[1]:.1f} "
    return d

def series(n, seed, drift=0.0, vol=1.0, start=0.5):
    random.seed(seed)
    v = start; out=[]
    for i in range(n):
        v += drift + random.uniform(-vol, vol)
        v = max(0.06, min(0.94, v))
        out.append(v)
    return out

def panel(title_bars=True, toolbar_right=""):
    """Outer chrome shared by all three: panel, border, toolbar skeleton."""
    s = f'<rect x="0" y="0" width="{W}" height="{H}" rx="14" fill="{BG}"/>'
    s += f'<rect x="0.5" y="0.5" width="{W-1}" height="{H-1}" rx="13.5" fill="none" stroke="{BORDER}"/>'
    # toolbar divider
    s += f'<line x1="16" y1="46" x2="{W-16}" y2="46" stroke="{BORDER}"/>'
    if title_bars:
        # symbol skeleton (ticker + name) top-left
        s += f'<rect x="18" y="17" width="70" height="13" rx="3" fill="{MUTED}"/>'
        s += f'<rect x="96" y="19" width="46" height="9" rx="3" fill="{GRID}"/>'
    return s

def timeframe_pills(x=560, y=15):
    labels = ["1D","1W","1M","1Y"]
    s=""; cx=x
    for i,l in enumerate(labels):
        active = (i==2)
        fill = "#152232" if active else "none"
        stroke = CYAN if active else BORDER
        tcol = CYAN if active else AXIS
        s += f'<rect x="{cx}" y="{y}" width="42" height="20" rx="5" fill="{fill}" stroke="{stroke}"/>'
        s += f'<text x="{cx+21}" y="{y+14}" font-family="{MONO}" font-size="11" fill="{tcol}" text-anchor="middle">{l}</text>'
        cx += 48
    return s

# ---------- geometry of plot area ----------
PX0, PX1 = 18, 720      # plot x range (right gutter = price axis)
PY0, PY1 = 62, 452      # plot y range
AXISX = 726             # x where price labels start

def grid_and_axes(levels, price_lo, price_hi, time_labels, pct=False):
    s = f'<rect x="{PX0}" y="{PY0}" width="{PX1-PX0}" height="{PY1-PY0}" fill="{PANEL}"/>'
    # horizontal grid + price ticks
    for i in range(levels+1):
        gy = PY0 + (PY1-PY0)*i/levels
        s += f'<line x1="{PX0}" y1="{gy:.1f}" x2="{PX1}" y2="{gy:.1f}" stroke="{GRID}"/>'
        val = price_hi - (price_hi-price_lo)*i/levels
        txt = f"{val:+.1f}%" if pct else f"{val:,.2f}"
        s += f'<text x="{AXISX}" y="{gy+3.5:.1f}" font-family="{MONO}" font-size="10.5" fill="{AXIS}">{txt}</text>'
    # vertical grid + time ticks
    n=len(time_labels)
    for i,lab in enumerate(time_labels):
        gx = PX0 + (PX1-PX0)*i/(n-1)
        s += f'<line x1="{gx:.1f}" y1="{PY0}" x2="{gx:.1f}" y2="{PY1}" stroke="{GRID2}"/>'
        s += f'<text x="{gx:.1f}" y="{PY1+18}" font-family="{MONO}" font-size="10" fill="{AXIS}" text-anchor="middle">{lab}</text>'
    return s

def crosshair(cx, cy, price_txt, time_txt, tag_color=AMBER):
    s = f'<line x1="{cx:.1f}" y1="{PY0}" x2="{cx:.1f}" y2="{PY1}" stroke="{AXIS}" stroke-dasharray="2 3" opacity="0.55"/>'
    s += f'<line x1="{PX0}" y1="{cy:.1f}" x2="{PX1}" y2="{cy:.1f}" stroke="{AXIS}" stroke-dasharray="2 3" opacity="0.55"/>'
    # price tag on right axis
    s += f'<rect x="{PX1+2}" y="{cy-9:.1f}" width="52" height="18" rx="3" fill="{tag_color}"/>'
    s += f'<text x="{PX1+28}" y="{cy+3.5:.1f}" font-family="{MONO}" font-size="10.5" fill="#0B0E13" text-anchor="middle" font-weight="600">{price_txt}</text>'
    # time tag on bottom axis
    tw=46
    s += f'<rect x="{cx-tw/2:.1f}" y="{PY1+4}" width="{tw}" height="17" rx="3" fill="#1B2534"/>'
    s += f'<text x="{cx:.1f}" y="{PY1+16}" font-family="{MONO}" font-size="9.5" fill="#AEB9C7" text-anchor="middle">{time_txt}</text>'
    return s

TIME_LABELS = ["09:00","10:30","12:00","13:30","15:00","16:30"]

# ========== 1) AREA / LINE TIME-SERIES ==========
def svg_area():
    n=64
    raw = series(n, 7, drift=0.006, vol=0.05, start=0.32)
    pts=[]
    for i,v in enumerate(raw):
        x = PX0 + (PX1-PX0)*i/(n-1)
        y = PY1 - (PY1-PY0)*v
        pts.append((x,y))
    line = catmull_to_path(pts)
    area = line + f" L {PX1},{PY1} L {PX0},{PY1} Z"
    ci = int(n*0.66); cx,cy = pts[ci]
    body  = panel() + timeframe_pills()
    body += grid_and_axes(5, 1.2712, 1.2795, TIME_LABELS)
    body += f'<path d="{area}" fill="url(#gArea)" opacity="0.9"/>'
    body += f'<path d="{line}" fill="none" stroke="{CYAN}" stroke-width="2" opacity="0.92"/>'
    body += crosshair(cx, cy, "1.2764", "13:12")
    body += f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="3.4" fill="{CYAN}" stroke="{BG}" stroke-width="1.5"/>'
    defs = f'''<defs>
      <linearGradient id="gArea" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="{CYAN}" stop-opacity="0.30"/>
        <stop offset="1" stop-color="{CYAN}" stop-opacity="0.02"/>
      </linearGradient></defs>'''
    return wrap(defs+body)

# ========== 2) CANDLESTICK + VOLUME ==========
def svg_candles():
    global PY1
    plot_bottom = 392            # leave room for volume strip
    n=46
    random.seed(21)
    price=0.45; ohlc=[]
    for i in range(n):
        o=price
        drift=0.004
        c=max(0.08,min(0.92,o+drift+random.uniform(-0.05,0.05)))
        hi=max(o,c)+random.uniform(0.005,0.03)
        lo=min(o,c)-random.uniform(0.005,0.03)
        hi=min(0.96,hi); lo=max(0.05,lo)
        ohlc.append((o,hi,lo,c)); price=c
    def Y(v): return plot_bottom - (plot_bottom-PY0)*v
    slot=(PX1-PX0)/n; bw=slot*0.58
    body = panel() + timeframe_pills()
    # grid/axes but with custom bottom
    body += f'<rect x="{PX0}" y="{PY0}" width="{PX1-PX0}" height="{plot_bottom-PY0}" fill="{PANEL}"/>'
    for i in range(6):
        gy=PY0+(plot_bottom-PY0)*i/5
        body += f'<line x1="{PX0}" y1="{gy:.1f}" x2="{PX1}" y2="{gy:.1f}" stroke="{GRID}"/>'
        val=17240-(i*38)
        body += f'<text x="{AXISX}" y="{gy+3.5:.1f}" font-family="{MONO}" font-size="10.5" fill="{AXIS}">{val:,}</text>'
    for i,lab in enumerate(TIME_LABELS):
        gx=PX0+(PX1-PX0)*i/(len(TIME_LABELS)-1)
        body += f'<line x1="{gx:.1f}" y1="{PY0}" x2="{gx:.1f}" y2="452" stroke="{GRID2}"/>'
        body += f'<text x="{gx:.1f}" y="470" font-family="{MONO}" font-size="10" fill="{AXIS}" text-anchor="middle">{lab}</text>'
    # moving average line (over closes)
    ma=[]
    closes=[c for _,_,_,c in ohlc]
    for i in range(n):
        w=closes[max(0,i-4):i+1]; ma.append(sum(w)/len(w))
    mapts=[(PX0+slot*(i+0.5), Y(ma[i])) for i in range(n)]
    body += f'<path d="{catmull_to_path(mapts)}" fill="none" stroke="{AMBER}" stroke-width="1.4" opacity="0.75"/>'
    # candles
    lastc=None
    for i,(o,hi,lo,c) in enumerate(ohlc):
        cx=PX0+slot*i+slot/2
        up = c>=o
        col = GREEN if up else RED
        body += f'<line x1="{cx:.1f}" y1="{Y(hi):.1f}" x2="{cx:.1f}" y2="{Y(lo):.1f}" stroke="{col}" stroke-width="1" opacity="0.9"/>'
        top=Y(max(o,c)); bot=Y(min(o,c)); h=max(1.2,bot-top)
        fill = col if up else col
        op = 0.92 if up else 0.9
        body += f'<rect x="{cx-bw/2:.1f}" y="{top:.1f}" width="{bw:.1f}" height="{h:.1f}" rx="0.8" fill="{fill}" opacity="{op}"/>'
        lastc=(cx,Y(c),c)
    # volume strip
    vy0, vy1 = 404, 448
    random.seed(5)
    for i,(o,hi,lo,c) in enumerate(ohlc):
        cx=PX0+slot*i+slot/2
        vh=random.uniform(6,40)
        col = GREEN if c>=o else RED
        body += f'<rect x="{cx-bw/2:.1f}" y="{vy1-vh:.1f}" width="{bw:.1f}" height="{vh:.1f}" fill="{col}" opacity="0.22"/>'
    body += f'<text x="{PX0+4}" y="{vy0-2}" font-family="{MONO}" font-size="9" fill="{AXIS}">VOL</text>'
    # crosshair on last close
    cx,cy,_=lastc
    body += f'<line x1="{cx:.1f}" y1="{PY0}" x2="{cx:.1f}" y2="{plot_bottom}" stroke="{AXIS}" stroke-dasharray="2 3" opacity="0.5"/>'
    body += f'<line x1="{PX0}" y1="{cy:.1f}" x2="{PX1}" y2="{cy:.1f}" stroke="{AXIS}" stroke-dasharray="2 3" opacity="0.5"/>'
    body += f'<rect x="{PX1+2}" y="{cy-9:.1f}" width="52" height="18" rx="3" fill="{GREEN}"/>'
    body += f'<text x="{PX1+28}" y="{cy+3.5:.1f}" font-family="{MONO}" font-size="10.5" fill="#0B0E13" text-anchor="middle" font-weight="600">17,182</text>'
    # legend chip
    body += f'<rect x="18" y="54" width="9" height="9" rx="2" fill="{AMBER}" opacity="0.8"/>'
    body += f'<text x="31" y="62" font-family="{MONO}" font-size="10" fill="{AXIS}">MA(5)</text>'
    return wrap(body)

# ========== 3) COMPARISON (two normalized series) ==========
def svg_compare():
    n=60
    a=series(n, 3, drift=0.004, vol=0.045, start=0.5)
    b=series(n, 11, drift=0.001, vol=0.05, start=0.5)
    def path_for(arr):
        pts=[(PX0+(PX1-PX0)*i/(n-1), PY1-(PY1-PY0)*v) for i,v in enumerate(arr)]
        return catmull_to_path(pts), pts
    pa,ptsa=path_for(a); pb,ptsb=path_for(b)
    body = panel() + timeframe_pills()
    body += grid_and_axes(5, 6.0, -3.0, TIME_LABELS, pct=True)
    # zero baseline emphasis (middle-ish)
    body += f'<path d="{pb}" fill="none" stroke="{AMBER}" stroke-width="1.9" opacity="0.85"/>'
    body += f'<path d="{pa}" fill="none" stroke="{CYAN}" stroke-width="1.9" opacity="0.9"/>'
    # end dots + tags
    for pts,col,tag in [(ptsa,CYAN,"+4.8%"),(ptsb,AMBER,"+1.2%")]:
        ex,ey=pts[-1]
        body += f'<circle cx="{ex:.1f}" cy="{ey:.1f}" r="3" fill="{col}"/>'
        body += f'<rect x="{PX1+2}" y="{ey-9:.1f}" width="52" height="18" rx="3" fill="{col}"/>'
        body += f'<text x="{PX1+28}" y="{ey+3.5:.1f}" font-family="{MONO}" font-size="10" fill="#0B0E13" text-anchor="middle" font-weight="600">{tag}</text>'
    # legend two series
    body += f'<rect x="18" y="54" width="9" height="9" rx="2" fill="{CYAN}"/>'
    body += f'<text x="31" y="62" font-family="{MONO}" font-size="10" fill="{AXIS}">SERIES A</text>'
    body += f'<rect x="104" y="54" width="9" height="9" rx="2" fill="{AMBER}"/>'
    body += f'<text x="117" y="62" font-family="{MONO}" font-size="10" fill="{AXIS}">SERIES B</text>'
    return wrap(body)

def wrap(inner):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
            f'width="{W}" height="{H}" role="img" aria-label="Chart placeholder">'
            f'{inner}</svg>')

import os
out="/mnt/user-data/outputs/trading-placeholders"
os.makedirs(out, exist_ok=True)
open(f"{out}/terminal-area.svg","w").write(svg_area())
open(f"{out}/terminal-candles.svg","w").write(svg_candles())
open(f"{out}/terminal-compare.svg","w").write(svg_compare())
print("written")
