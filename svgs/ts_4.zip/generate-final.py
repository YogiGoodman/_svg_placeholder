import math, random, os

W, H = 640, 360
SANS = "'Inter','Segoe UI',system-ui,sans-serif"

def catmull(pts):
    if len(pts) < 3:
        return "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    d = f"M {pts[0][0]:.1f},{pts[0][1]:.1f} "
    for i in range(len(pts) - 1):
        p0 = pts[i-1] if i > 0 else pts[0]
        p1, p2 = pts[i], pts[i+1]
        p3 = pts[i+2] if i+2 < len(pts) else pts[-1]
        c1 = (p1[0]+(p2[0]-p0[0])/6, p1[1]+(p2[1]-p0[1])/6)
        c2 = (p2[0]-(p3[0]-p1[0])/6, p2[1]-(p3[1]-p1[1])/6)
        d += f"C {c1[0]:.1f},{c1[1]:.1f} {c2[0]:.1f},{c2[1]:.1f} {p2[0]:.1f},{p2[1]:.1f} "
    return d

def frame():
    s  = f'<rect x="4" y="4" width="{W-8}" height="{H-8}" rx="14" fill="currentColor" fill-opacity="0.022"/>'
    s += f'<rect x="4.5" y="4.5" width="{W-9}" height="{H-9}" rx="13.5" fill="none" stroke="currentColor" stroke-opacity="0.16" stroke-width="1" stroke-dasharray="5 5"/>'
    return s

def wrap(inner, color="#94a3b8"):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
            f'width="{W}" height="{H}" fill="none" role="img" '
            f'aria-label="Chart placeholder" style="color:{color}">{inner}</svg>')

def line_in(bb, arr, op=0.44, w=1.6, dash=None):
    x0, y0, x1, y1 = bb
    pts = [(x0 + (x1-x0)*i/(len(arr)-1), y1 - (y1-y0)*v) for i, v in enumerate(arr)]
    da = f' stroke-dasharray="{dash}"' if dash else ''
    return (f'<path d="{catmull(pts)}" fill="none" stroke="currentColor" stroke-opacity="{op}" '
            f'stroke-width="{w}"{da} stroke-linecap="round"/>'), pts

def clabel(x, y, text, op=0.5, size=10):
    return (f'<text x="{x}" y="{y}" font-family="{SANS}" font-size="{size}" letter-spacing="1.2" '
            f'fill="currentColor" fill-opacity="{op}" font-weight="600">{text}</text>')

# ---------------- shared glyphs (bb, k scales stroke/markers) ----------------
def g_latest(bb, k=1.0):
    arr = [0.30,0.42,0.36,0.5,0.46,0.58,0.54,0.66,0.7]
    p, pts = line_in(bb, arr, op=0.46, w=1.7*k)
    for idx in (2,5,8):
        x,y = pts[idx]
        p += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{2.4*k:.1f}" fill="currentColor" fill-opacity="0.5"/>'
    return p

def g_asof(bb, k=1.0):
    arr = [0.34,0.48,0.4,0.56,0.52,0.64,0.6]
    p, pts = line_in(bb, arr, op=0.44, w=1.6*k)
    mx,my = pts[4]
    p += f'<line x1="{mx:.1f}" y1="{bb[1]}" x2="{mx:.1f}" y2="{bb[3]}" stroke="currentColor" stroke-opacity="0.26" stroke-dasharray="2 3"/>'
    p += f'<circle cx="{mx:.1f}" cy="{my:.1f}" r="{2.8*k:.1f}" fill="currentColor" fill-opacity="0.6"/>'
    return p

def g_curve(bb, k=1.0):
    x0,y0,x1,y1 = bb
    arr = [0.26,0.4,0.5,0.57,0.61,0.63,0.64]
    p, pts = line_in(bb, arr, op=0.44, w=1.7*k)
    for (x,y) in pts:
        p += f'<line x1="{x:.1f}" y1="{y:.1f}" x2="{x:.1f}" y2="{y1:.1f}" stroke="currentColor" stroke-opacity="0.13"/>'
        p += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{2.6*k:.1f}" fill="currentColor" fill-opacity="0.55"/>'
    return p

def g_seasonal(bb, k=1.0):
    p = ""
    for ph, op in [(0.0,0.44),(0.8,0.28),(1.7,0.18)]:
        arr = [0.5 + 0.32*math.sin(2*math.pi*(t/11) + ph) for t in range(12)]
        seg,_ = line_in(bb, arr, op=op, w=1.5*k); p += seg
    return p

def g_vintage(bb, k=1.0):
    x0,y0,x1,y1 = bb
    split = x0 + (x1-x0)*0.4
    hist = [0.4,0.46,0.44,0.5]
    ph, pts = line_in((x0,y0,split,y1), hist, op=0.44, w=1.7*k)
    p = ph
    start = pts[-1]
    for end_v, op, dash in [(0.72,0.42,None),(0.6,0.3,"3 3"),(0.5,0.22,"2 4")]:
        ex, ey = x1, y1-(y1-y0)*end_v
        mid = ((start[0]+ex)/2, (start[1]+ey)/2 - 5)
        d = f"M {start[0]:.1f},{start[1]:.1f} Q {mid[0]:.1f},{mid[1]:.1f} {ex:.1f},{ey:.1f}"
        da = f' stroke-dasharray="{dash}"' if dash else ''
        p += f'<path d="{d}" fill="none" stroke="currentColor" stroke-opacity="{op}" stroke-width="{1.6*k}"{da} stroke-linecap="round"/>'
    p += f'<line x1="{split:.1f}" y1="{y0}" x2="{split:.1f}" y2="{y1}" stroke="currentColor" stroke-opacity="0.15" stroke-dasharray="2 3"/>'
    return p

def g_candles(bb, k=1.0):
    random.seed(3)
    x0,y0,x1,y1 = bb
    n=6; slot=(x1-x0)/n; bw=slot*0.46; price=0.45; p=""
    def Y(v): return y1-(y1-y0)*v
    for i in range(n):
        o=price; c=max(0.2,min(0.8,o+0.02+random.uniform(-0.05,0.05)))
        hi=min(0.9,max(o,c)+0.06); lo=max(0.1,min(o,c)-0.06)
        cx=x0+slot*i+slot/2
        p += f'<line x1="{cx:.1f}" y1="{Y(hi):.1f}" x2="{cx:.1f}" y2="{Y(lo):.1f}" stroke="currentColor" stroke-opacity="0.2" stroke-width="{1.4*k}"/>'
        top=Y(max(o,c)); h=max(3,Y(min(o,c))-top)
        p += f'<rect x="{cx-bw/2:.1f}" y="{top:.1f}" width="{bw:.1f}" height="{h:.1f}" rx="1.2" fill="currentColor" fill-opacity="0.26"/>'
        price=c
    return p

# ================= 1) ENERGY QUADRANT — symmetric grid =================
def energy_quadrant():
    # symmetric content box + centered dividers
    CX0, CY0, CX1, CY1 = 26, 26, W-26, H-26      # 26,26,614,334
    DX, DY = (CX0+CX1)/2, (CY0+CY1)/2            # 320,180
    GUT = 16
    LABEL_DY, GLYPH_TOP_DY, GLYPH_H = 22, 34, 104
    colX = {0: (CX0, DX-GUT), 1: (DX+GUT, CX1)}  # left (26,304) / right (336,614)
    bandY = {0: CY0, 1: DY}                       # top 26 / bottom 180

    s = frame()
    # faint divider cross
    s += f'<line x1="{DX}" y1="{CY0}" x2="{DX}" y2="{CY1}" stroke="currentColor" stroke-opacity="0.10"/>'
    s += f'<line x1="{CX0}" y1="{DY}" x2="{CX1}" y2="{DY}" stroke="currentColor" stroke-opacity="0.10"/>'

    cells = [
        (0, 0, "LATEST",           g_latest),
        (1, 0, "FORWARD CURVE",    g_curve),
        (0, 1, "SEASONAL",         g_seasonal),
        (1, 1, "FORECAST VINTAGE", g_vintage),
    ]
    for col, row, name, fn in cells:
        gx0, gx1 = colX[col]
        bt = bandY[row]
        s += clabel(gx0, bt + LABEL_DY, name)
        bb = (gx0, bt + GLYPH_TOP_DY, gx1, bt + GLYPH_TOP_DY + GLYPH_H)
        s += fn(bb)
    return wrap(s)

# ================= 2) HERO + DOCK — reordered by importance =================
def clabel_c(x, y, text, op, size=8.5):
    return (f'<text x="{x}" y="{y}" font-family="{SANS}" font-size="{size}" letter-spacing="1.0" '
            f'fill="currentColor" fill-opacity="{op}" font-weight="600" text-anchor="middle">{text}</text>')

def hero_dock():
    s = frame()
    s += (f'<text x="26" y="28" font-family="{SANS}" font-size="10" letter-spacing="1.2" '
          f'fill="currentColor" fill-opacity="0.5" font-weight="600">LATEST</text>')
    hb = (28, 40, 612, 244); x0,y0,x1,y1 = hb
    for i in range(1,4):
        gy = y0+(y1-y0)*i/4
        s += f'<line x1="{x0}" y1="{gy:.1f}" x2="{x1}" y2="{gy:.1f}" stroke="currentColor" stroke-opacity="0.05"/>'
    arr = [0.34,0.4,0.36,0.46,0.42,0.5,0.47,0.55,0.52,0.6,0.58,0.66,0.63,0.7]
    pts = [(x0+(x1-x0)*i/(len(arr)-1), y1-(y1-y0)*v) for i,v in enumerate(arr)]
    ln = catmull(pts)
    s += ('<defs><linearGradient id="hg" x1="0" y1="0" x2="0" y2="1">'
          '<stop offset="0" stop-color="currentColor" stop-opacity="0.10"/>'
          '<stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>')
    s += f'<path d="{ln} L {x1},{y1} L {x0},{y1} Z" fill="url(#hg)"/>'
    s += f'<path d="{ln}" fill="none" stroke="currentColor" stroke-opacity="0.42" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
    for (x,y) in pts[::2]:
        s += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.4" fill="currentColor" fill-opacity="0.5"/>'
    s += f'<line x1="28" y1="262" x2="612" y2="262" stroke="currentColor" stroke-opacity="0.1"/>'

    # dock ordered by trader importance: price -> forward structure -> seasonality
    #                                    -> fundamental -> price action -> data review
    dock = [("LATEST",g_latest),("FWD CURVE",g_curve),("SEASONAL",g_seasonal),
            ("VINTAGE",g_vintage),("OHLC",g_candles),("AS-OF",g_asof)]
    dx0, dx1 = 28, 612; n=6; cw=(dx1-dx0)/n; cy0, cy1 = 274, 322
    for i,(name,fn) in enumerate(dock):
        cx0 = dx0+cw*i+4; cx1 = dx0+cw*(i+1)-4
        active = (i==0)
        fo = 0.05 if active else 0.02
        so = 0.28 if active else 0.10
        s += f'<rect x="{cx0:.1f}" y="{cy0}" width="{cx1-cx0:.1f}" height="{cy1-cy0}" rx="6" fill="currentColor" fill-opacity="{fo}" stroke="currentColor" stroke-opacity="{so}"/>'
        s += fn((cx0+10, cy0+11, cx1-10, cy1-11), k=0.8)
        s += clabel_c((cx0+cx1)/2, 340, name, op=0.5 if active else 0.4)
    return wrap(s)

out = "/mnt/user-data/outputs/subtle-placeholders"
os.makedirs(out, exist_ok=True)
open(f"{out}/placeholder-energy-quadrant.svg","w").write(energy_quadrant())
open(f"{out}/placeholder-hero-dock.svg","w").write(hero_dock())
print("written")
