import os

W, H = 640, 360
MONO = "ui-monospace,'SF Mono',Menlo,Consolas,monospace"

def catmull(pts):
    if len(pts) < 3:
        return "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    d = f"M {pts[0][0]:.1f},{pts[0][1]:.1f} "
    for i in range(len(pts) - 1):
        p0 = pts[i-1] if i > 0 else pts[0]
        p1, p2 = pts[i], pts[i+1]
        p3 = pts[i+2] if i+2 < len(pts) else pts[-1]
        c1 = (p1[0]+(p2[0]-p0[0])/6, p1[1]+(p2[1]-p0[1])/6)
        c2 = (p2[0]-(p3[0]-p1[0])/6, p2[1]-(p3[1]-p1[1])/6)
        d += f"C {c1[0]:.1f},{c1[1]:.1f} {c2[0]:.1f},{c2[1]:.1f} {p2[0]:.1f},{p2[1]:.1f} "
    return d

def wrap(inner, color="#94a3b8"):
    # decorative: aria-hidden + focusable=false, no role/aria-label (message lives in the DOM)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" '
            f'fill="none" aria-hidden="true" focusable="false" style="color:{color}">{inner}</svg>')

def ghost(text):
    return (f'<text x="{W/2}" y="230" font-family="{MONO}" font-size="150" font-weight="700" '
            f'letter-spacing="12" text-anchor="middle" '
            f'fill="currentColor" fill-opacity="0.05" '
            f'stroke="currentColor" stroke-opacity="0.09" stroke-width="1">{text}</text>')

# ---------------- 404 : broken data path (clean) ----------------
def svg_404():
    s = ghost("404")
    left  = [(96,206),(150,184),(202,196),(252,160),(294,148)]
    right = [(346,166),(398,140),(450,154),(502,126),(546,140)]
    for seg in (left, right):
        s += (f'<path d="{catmull(seg)}" fill="none" stroke="currentColor" stroke-opacity="0.44" '
              f'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>')
    # two hollow, disconnected end-nodes with a clean vertical step = severed path
    for (x,y) in [(294,148),(346,166)]:
        s += (f'<circle cx="{x}" cy="{y}" r="4.5" fill="currentColor" fill-opacity="0.06" '
              f'stroke="currentColor" stroke-opacity="0.5" stroke-width="1.6"/>')
    return wrap(s)

# ---------------- 403 : forbidden / locked (clean) ----------------
def svg_403():
    s = ghost("403")
    # one calm chart line behind (keeps the trading nod without clutter)
    behind = [(120,196),(220,178),(320,188),(420,172),(520,182)]
    s += f'<path d="{catmull(behind)}" fill="none" stroke="currentColor" stroke-opacity="0.09" stroke-width="1.6"/>'
    cx, bt = 320, 160
    bw, bh = 78, 56
    at, lx = bt - 32, 18
    # shackle
    s += (f'<path d="M {cx-lx},{bt} L {cx-lx},{at} A {lx},{lx} 0 0 1 {cx+lx},{at} L {cx+lx},{bt}" '
          f'fill="none" stroke="currentColor" stroke-opacity="0.42" stroke-width="3.2" stroke-linecap="round"/>')
    # body
    s += (f'<rect x="{cx-bw/2}" y="{bt}" width="{bw}" height="{bh}" rx="10" '
          f'fill="currentColor" fill-opacity="0.05" stroke="currentColor" stroke-opacity="0.42" stroke-width="2.4"/>')
    # keyhole
    ky = bt + 22
    s += f'<circle cx="{cx}" cy="{ky}" r="6" fill="currentColor" fill-opacity="0.5"/>'
    s += f'<path d="M {cx-3.2},{ky+3} L {cx+3.2},{ky+3} L {cx+5},{bt+bh-9} L {cx-5},{bt+bh-9} Z" fill="currentColor" fill-opacity="0.5"/>'
    return wrap(s)

out = "/mnt/user-data/outputs/error-illustrations"
os.makedirs(out, exist_ok=True)
open(f"{out}/error-404-path.svg","w").write(svg_404())
open(f"{out}/error-403-forbidden.svg","w").write(svg_403())
print("written")
