import math, random, os

W, H = 640, 360
PAD_X, PAD_T, PAD_B = 28, 28, 32
X0, X1 = PAD_X, W - PAD_X
Y0, Y1 = PAD_T, H - PAD_B
SANS = "'Inter','Segoe UI',system-ui,sans-serif"

def catmull(pts):
    if len(pts) < 3:
        return "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    d = f"M {pts[0][0]:.1f},{pts[0][1]:.1f} "
    for i in range(len(pts) - 1):
        p0 = pts[i-1] if i > 0 else pts[0]
        p1, p2 = pts[i], pts[i+1]
        p3 = pts[i+2] if i+2 < len(pts) else pts[-1]
        c1 = (p1[0]+(p2[0]-p0[0])/6, p1[1]+(p2[1]-p0[1])/6)
        c2 = (p2[0]-(p3[0]-p1[0])/6, p2[1]-(p3[1]-p1[1])/6)
        d += f"C {c1[0]:.1f},{c1[1]:.1f} {c2[0]:.1f},{c2[1]:.1f} {p2[0]:.1f},{p2[1]:.1f} "
    return d

def frame():
    s  = f'<rect x="4" y="4" width="{W-8}" height="{H-8}" rx="14" fill="currentColor" fill-opacity="0.022"/>'
    s += f'<rect x="4.5" y="4.5" width="{W-9}" height="{H-9}" rx="13.5" fill="none" stroke="currentColor" stroke-opacity="0.16" stroke-width="1" stroke-dasharray="5 5"/>'
    return s

def wrap(inner, color="#94a3b8"):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
            f'width="{W}" height="{H}" fill="none" role="img" '
            f'aria-label="Chart placeholder" style="color:{color}">{inner}</svg>')

# ================= 1) time-series with visible data points =================
def points_svg():
    n = 14
    random.seed(6); v = 0.4; raw = []
    for i in range(n):
        v += 0.012 + random.uniform(-0.05, 0.05)
        v = max(0.15, min(0.85, v)); raw.append(v)
    pts = [(X0 + (X1-X0)*i/(n-1), Y1 - (Y1-Y0)*val) for i, val in enumerate(raw)]
    line = catmull(pts)
    area = line + f" L {X1},{Y1} L {X0},{Y1} Z"
    s  = frame()
    for i in range(1, 4):
        gy = Y0 + (Y1 - Y0) * i / 4
        s += f'<line x1="{X0}" y1="{gy:.1f}" x2="{X1}" y2="{gy:.1f}" stroke="currentColor" stroke-opacity="0.06"/>'
    s += ('<defs><linearGradient id="pg" x1="0" y1="0" x2="0" y2="1">'
          '<stop offset="0" stop-color="currentColor" stop-opacity="0.10"/>'
          '<stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>')
    s += f'<path d="{area}" fill="url(#pg)"/>'
    s += f'<path d="{line}" fill="none" stroke="currentColor" stroke-opacity="0.4" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>'
    # data points: soft halo + solid dot
    for (x, y) in pts:
        s += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="5" fill="currentColor" fill-opacity="0.10"/>'
        s += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.6" fill="currentColor" fill-opacity="0.62"/>'
    return wrap(s)

# ================= 2) four-quadrant chart-type grid =================
def cell_label(x, y, text):
    return (f'<text x="{x}" y="{y}" font-family="{SANS}" font-size="10" letter-spacing="1.2" '
            f'fill="currentColor" fill-opacity="0.5" font-weight="600">{text}</text>')

def mini_line(bb, arr, dash=None, opacity=0.44, width=1.6):
    x0, y0, x1, y1 = bb
    pts = [(x0 + (x1-x0)*i/(len(arr)-1), y1 - (y1-y0)*v) for i, v in enumerate(arr)]
    d = catmull(pts)
    da = f' stroke-dasharray="{dash}"' if dash else ''
    return f'<path d="{d}" fill="none" stroke="currentColor" stroke-opacity="{opacity}" stroke-width="{width}"{da} stroke-linecap="round"/>', pts

def quadrant_svg():
    s = frame()
    midx, midy = W/2, H/2 + 4
    # faint divider cross
    s += f'<line x1="{midx}" y1="{Y0-2}" x2="{midx}" y2="{Y1+2}" stroke="currentColor" stroke-opacity="0.10"/>'
    s += f'<line x1="{X0-2}" y1="{midy}" x2="{X1+2}" y2="{midy}" stroke="currentColor" stroke-opacity="0.10"/>'

    # cell inner plot boxes (leave room for label at top)
    def box(col, row):
        cx0 = X0 + (midx - X0) * 0 if col == 0 else midx + 14
        gx0 = (X0 + 14) if col == 0 else (midx + 14)
        gx1 = (midx - 14) if col == 0 else (X1 - 14)
        gy0 = (Y0 + 26) if row == 0 else (midy + 26)
        gy1 = (midy - 14) if row == 0 else (Y1 - 8)
        return gx0, gy0, gx1, gy1
    def label_pos(col, row):
        lx = (X0 + 14) if col == 0 else (midx + 14)
        ly = (Y0 + 16) if row == 0 else (midy + 16)
        return lx, ly

    random.seed(2)
    # -- AS-OF (top-left): line + vertical as-of marker + dot
    bb = box(0, 0); lx, ly = label_pos(0, 0)
    s += cell_label(lx, ly, "AS-OF")
    arr = [0.35, 0.5, 0.42, 0.6, 0.55, 0.7, 0.63, 0.72]
    p, pts = mini_line(bb, arr); s += p
    mx, my = pts[5]
    s += f'<line x1="{mx:.1f}" y1="{bb[1]}" x2="{mx:.1f}" y2="{bb[3]}" stroke="currentColor" stroke-opacity="0.28" stroke-dasharray="2 3"/>'
    s += f'<circle cx="{mx:.1f}" cy="{my:.1f}" r="3" fill="currentColor" fill-opacity="0.6"/>'

    # -- SEASONAL (top-right): overlapping yearly curves
    bb = box(1, 0); lx, ly = label_pos(1, 0)
    s += cell_label(lx, ly, "SEASONAL")
    for k, (ph, op) in enumerate([(0.0, 0.42), (0.7, 0.26), (1.5, 0.16)]):
        arr = [0.5 + 0.32*math.sin(2*math.pi*(t/11) + ph) for t in range(12)]
        p, _ = mini_line(bb, arr, opacity=op, width=1.5); s += p

    # -- FORECAST (bottom-left): solid -> dashed + widening band
    bb = box(0, 1); lx, ly = label_pos(0, 1)
    s += cell_label(lx, ly, "FORECAST")
    x0, y0, x1, y1 = bb
    hist = [0.4, 0.46, 0.44, 0.52, 0.5, 0.58]
    fc   = [0.58, 0.62, 0.6, 0.66]     # continues from last hist
    ph, pth = mini_line((x0, y0, x0 + (x1-x0)*0.55, y1), hist, opacity=0.44, width=1.6)
    s += ph
    # forecast segment on right 45%
    fx0 = x0 + (x1-x0)*0.55
    fpts = [(fx0 + (x1-fx0)*i/(len(fc)-1), y1 - (y1-y0)*v) for i, v in enumerate(fc)]
    # band
    band_up = " ".join(f"{x:.1f},{y-4-6*i:.1f}" for i,(x,y) in enumerate(fpts))
    band_dn = " ".join(f"{x:.1f},{y+4+6*i:.1f}" for i,(x,y) in reversed(list(enumerate(fpts))))
    s += f'<polygon points="{band_up} {band_dn}" fill="currentColor" fill-opacity="0.07"/>'
    s += f'<path d="{catmull(fpts)}" fill="none" stroke="currentColor" stroke-opacity="0.4" stroke-width="1.6" stroke-dasharray="3 3" stroke-linecap="round"/>'
    s += f'<line x1="{fx0:.1f}" y1="{y0}" x2="{fx0:.1f}" y2="{y1}" stroke="currentColor" stroke-opacity="0.16" stroke-dasharray="2 3"/>'

    # -- CURVE (bottom-right): forward curve with contract point markers
    bb = box(1, 1); lx, ly = label_pos(1, 1)
    s += cell_label(lx, ly, "CURVE")
    arr = [0.3, 0.42, 0.52, 0.58, 0.62, 0.64, 0.65]   # contango-ish, flattening
    p, pts = mini_line(bb, arr, opacity=0.44, width=1.7); s += p
    for (x, y) in pts:
        s += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.4" fill="currentColor" fill-opacity="0.55"/>'

    return wrap(s)

out = "/mnt/user-data/outputs/subtle-placeholders"
os.makedirs(out, exist_ok=True)
open(f"{out}/placeholder-points.svg", "w").write(points_svg())
open(f"{out}/placeholder-quadrant.svg", "w").write(quadrant_svg())
print("written")
