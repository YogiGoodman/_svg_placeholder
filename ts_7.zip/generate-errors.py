import os

W, H = 640, 360
SANS = "'Inter','Segoe UI',system-ui,sans-serif"
MONO = "ui-monospace,'SF Mono',Menlo,Consolas,monospace"

def catmull(pts):
    if len(pts) < 3:
        return "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    d = f"M {pts[0][0]:.1f},{pts[0][1]:.1f} "
    for i in range(len(pts) - 1):
        p0 = pts[i-1] if i > 0 else pts[0]
        p1, p2 = pts[i], pts[i+1]
        p3 = pts[i+2] if i+2 < len(pts) else pts[-1]
        c1 = (p1[0]+(p2[0]-p0[0])/6, p1[1]+(p2[1]-p0[1])/6)
        c2 = (p2[0]-(p3[0]-p1[0])/6, p2[1]-(p3[1]-p1[1])/6)
        d += f"C {c1[0]:.1f},{c1[1]:.1f} {c2[0]:.1f},{c2[1]:.1f} {p2[0]:.1f},{p2[1]:.1f} "
    return d

def wrap(inner, aria, color="#94a3b8"):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
            f'width="{W}" height="{H}" fill="none" role="img" aria-label="{aria}" '
            f'style="color:{color}">{inner}</svg>')

def ghost_number(text):
    # large faint watermark numerals
    return (f'<text x="{W/2}" y="206" font-family="{MONO}" font-size="150" font-weight="700" '
            f'letter-spacing="14" text-anchor="middle" '
            f'fill="currentColor" fill-opacity="0.05" '
            f'stroke="currentColor" stroke-opacity="0.09" stroke-width="1">{text}</text>')

def caption(primary, sub):
    s  = (f'<text x="{W/2}" y="268" font-family="{SANS}" font-size="13" font-weight="600" '
          f'letter-spacing="2.5" text-anchor="middle" fill="currentColor" fill-opacity="0.6" '
          f'aria-label="{primary}">{primary}</text>')
    s += (f'<text x="{W/2}" y="290" font-family="{SANS}" font-size="10.5" '
          f'letter-spacing="0.3" text-anchor="middle" fill="currentColor" fill-opacity="0.35">{sub}</text>')
    return s

def gridlines(ys):
    return "".join(f'<line x1="70" y1="{y}" x2="{W-70}" y2="{y}" stroke="currentColor" stroke-opacity="0.05"/>' for y in ys)

# ---------------- 404 : broken data path ----------------
def svg_404():
    s = ghost_number("404")
    s += gridlines([120, 165, 210])
    # left segment, rising, ends at a disconnected node
    left = [(78,214),(126,196),(172,206),(220,168),(262,150)]
    s += f'<path d="{catmull(left)}" fill="none" stroke="currentColor" stroke-opacity="0.44" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
    # right segment, starts at a disconnected node, continues
    right = [(378,158),(422,138),(466,152),(512,120),(562,132)]
    s += f'<path d="{catmull(right)}" fill="none" stroke="currentColor" stroke-opacity="0.44" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
    # broken bridge: two dashed stubs that stop short of each other (the missing link)
    s += f'<line x1="262" y1="150" x2="298" y2="152" stroke="currentColor" stroke-opacity="0.22" stroke-width="1.5" stroke-dasharray="2 4"/>'
    s += f'<line x1="378" y1="158" x2="342" y2="156" stroke="currentColor" stroke-opacity="0.22" stroke-width="1.5" stroke-dasharray="2 4"/>'
    # disconnected end-nodes (hollow)
    for (x,y) in [(262,150),(378,158)]:
        s += f'<circle cx="{x}" cy="{y}" r="4.5" fill="currentColor" fill-opacity="0.06" stroke="currentColor" stroke-opacity="0.5" stroke-width="1.6"/>'
    # subtle break marker at the gap centre
    cx = 320
    s += f'<line x1="{cx}" y1="140" x2="{cx}" y2="170" stroke="currentColor" stroke-opacity="0.16" stroke-dasharray="2 3"/>'
    s += caption("PAGE NOT FOUND", "The page you requested doesn\u2019t exist")
    return wrap(s, aria="Page not found")

# ---------------- 403 : forbidden / locked ----------------
def svg_403():
    s = ghost_number("403")
    # faint "locked" chart behind
    s += gridlines([120, 165, 210])
    behind = [(90,205),(150,185),(205,196),(260,172),(315,182),(370,158),(430,168),(490,150),(552,160)]
    s += f'<path d="{catmull(behind)}" fill="none" stroke="currentColor" stroke-opacity="0.10" stroke-width="1.6"/>'
    # padlock, centred (occupies the middle digit)
    cx, bt = 320, 150            # body top
    bw, bh = 78, 58
    bx0 = cx - bw/2
    # shackle (open at bottom, into body)
    at = bt - 34                 # arc top region
    lx = 18                      # leg half-spread
    s += (f'<path d="M {cx-lx},{bt} L {cx-lx},{at} A {lx},{lx} 0 0 1 {cx+lx},{at} L {cx+lx},{bt} " '
          f'fill="none" stroke="currentColor" stroke-opacity="0.42" stroke-width="3.2" stroke-linecap="round"/>')
    # body
    s += (f'<rect x="{bx0}" y="{bt}" width="{bw}" height="{bh}" rx="10" '
          f'fill="currentColor" fill-opacity="0.05" stroke="currentColor" stroke-opacity="0.42" stroke-width="2.4"/>')
    # keyhole
    ky = bt + 22
    s += f'<circle cx="{cx}" cy="{ky}" r="6" fill="currentColor" fill-opacity="0.5"/>'
    s += f'<path d="M {cx-3.2},{ky+3} L {cx+3.2},{ky+3} L {cx+5},{bt+bh-10} L {cx-5},{bt+bh-10} Z" fill="currentColor" fill-opacity="0.5"/>'
    s += caption("ACCESS FORBIDDEN", "You don\u2019t have permission to view this")
    return wrap(s, aria="Access forbidden")

out = "/mnt/user-data/outputs/error-illustrations"
os.makedirs(out, exist_ok=True)
open(f"{out}/error-404-path.svg","w").write(svg_404())
open(f"{out}/error-403-forbidden.svg","w").write(svg_403())
print("written")
