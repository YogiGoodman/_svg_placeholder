import math, os

W, H = 640, 360
SANS = "'Inter','Segoe UI',system-ui,sans-serif"

def catmull(pts):
    if len(pts) < 3:
        return "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    d = f"M {pts[0][0]:.1f},{pts[0][1]:.1f} "
    for i in range(len(pts) - 1):
        p0 = pts[i-1] if i > 0 else pts[0]
        p1, p2 = pts[i], pts[i+1]
        p3 = pts[i+2] if i+2 < len(pts) else pts[-1]
        c1 = (p1[0]+(p2[0]-p0[0])/6, p1[1]+(p2[1]-p0[1])/6)
        c2 = (p2[0]-(p3[0]-p1[0])/6, p2[1]-(p3[1]-p1[1])/6)
        d += f"C {c1[0]:.1f},{c1[1]:.1f} {c2[0]:.1f},{c2[1]:.1f} {p2[0]:.1f},{p2[1]:.1f} "
    return d

def frame():
    s  = f'<rect x="4" y="4" width="{W-8}" height="{H-8}" rx="14" fill="currentColor" fill-opacity="0.022"/>'
    s += f'<rect x="4.5" y="4.5" width="{W-9}" height="{H-9}" rx="13.5" fill="none" stroke="currentColor" stroke-opacity="0.16" stroke-width="1" stroke-dasharray="5 5"/>'
    return s

def wrap(inner, color="#94a3b8"):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
            f'width="{W}" height="{H}" fill="none" role="img" '
            f'aria-label="Chart placeholder" style="color:{color}">{inner}</svg>')

def line_in(bb, arr, op=0.44, w=1.6, dash=None):
    x0, y0, x1, y1 = bb
    pts = [(x0 + (x1-x0)*i/(len(arr)-1), y1 - (y1-y0)*v) for i, v in enumerate(arr)]
    da = f' stroke-dasharray="{dash}"' if dash else ''
    return (f'<path d="{catmull(pts)}" fill="none" stroke="currentColor" stroke-opacity="{op}" '
            f'stroke-width="{w}"{da} stroke-linecap="round"/>'), pts

def clabel(x, y, text, op=0.5, size=10):
    return (f'<text x="{x}" y="{y}" font-family="{SANS}" font-size="{size}" letter-spacing="1.2" '
            f'fill="currentColor" fill-opacity="{op}" font-weight="600">{text}</text>')

def g_latest(bb):
    arr = [0.30,0.42,0.36,0.5,0.46,0.58,0.54,0.66,0.7]
    p, pts = line_in(bb, arr, op=0.46, w=1.7)
    for idx in (2,5,8):
        x,y = pts[idx]; p += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.4" fill="currentColor" fill-opacity="0.5"/>'
    return p

def g_curve(bb):
    x0,y0,x1,y1 = bb
    arr = [0.22,0.38,0.5,0.58,0.63,0.66,0.67]
    p, pts = line_in(bb, arr, op=0.44, w=1.7)
    for (x,y) in pts:
        p += f'<line x1="{x:.1f}" y1="{y:.1f}" x2="{x:.1f}" y2="{y1:.1f}" stroke="currentColor" stroke-opacity="0.13"/>'
        p += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.6" fill="currentColor" fill-opacity="0.55"/>'
    return p

def g_seasonal(bb):
    p = ""
    for ph, op in [(0.0,0.44),(0.8,0.28),(1.7,0.18)]:
        arr = [0.5 + 0.34*math.sin(2*math.pi*(t/11) + ph) for t in range(12)]
        seg,_ = line_in(bb, arr, op=op, w=1.5); p += seg
    return p

def g_vintage(bb):
    # spread across the cell so the base isn't empty
    x0,y0,x1,y1 = bb
    split = x0 + (x1-x0)*0.4
    hist = [0.34,0.42,0.38,0.46]
    ph, pts = line_in((x0,y0,split,y1), hist, op=0.44, w=1.7)
    p = ph
    start = pts[-1]
    for end_v, op, dash in [(0.78,0.42,None),(0.58,0.3,"3 3"),(0.34,0.22,"2 4")]:
        ex, ey = x1, y1-(y1-y0)*end_v
        mid = ((start[0]+ex)/2, (start[1]+ey)/2 - 5)
        d = f"M {start[0]:.1f},{start[1]:.1f} Q {mid[0]:.1f},{mid[1]:.1f} {ex:.1f},{ey:.1f}"
        da = f' stroke-dasharray="{dash}"' if dash else ''
        p += f'<path d="{d}" fill="none" stroke="currentColor" stroke-opacity="{op}" stroke-width="1.6"{da} stroke-linecap="round"/>'
    p += f'<line x1="{split:.1f}" y1="{y0}" x2="{split:.1f}" y2="{y1}" stroke="currentColor" stroke-opacity="0.15" stroke-dasharray="2 3"/>'
    return p

def energy_quadrant():
    # --- horizontal: symmetric columns (unchanged; you liked these) ---
    CX0, CX1 = 26, W-26            # 26 .. 614
    DX = (CX0+CX1)/2              # 320
    GUT = 16
    colX = {0: (CX0, DX-GUT), 1: (DX+GUT, CX1)}   # left (26,304) / right (336,614)

    # --- vertical: mirror-symmetric about the divider ---
    # usable band runs frame-inset to frame-inset; divider sits at its exact centre,
    # and each row uses an IDENTICAL template measured from its own band edge.
    UTOP, UBOT = 14, H-14         # 14 .. 346  (centre = 180 = divider)
    DY = (UTOP+UBOT)/2            # 180
    rows = {0: (UTOP, DY), 1: (DY, UBOT)}          # top band / bottom band
    LABEL_DY   = 30               # label baseline below each band's top edge
    GLYPH_TOP  = 46               # glyph top below each band's top edge
    GLYPH_BOT_MARGIN = 22         # glyph bottom above each band's bottom edge

    s = frame()
    s += f'<line x1="{DX}" y1="{UTOP}" x2="{DX}" y2="{UBOT}" stroke="currentColor" stroke-opacity="0.10"/>'
    s += f'<line x1="{CX0}" y1="{DY}" x2="{CX1}" y2="{DY}" stroke="currentColor" stroke-opacity="0.10"/>'

    cells = [
        (0, 0, "LATEST",           g_latest),
        (1, 0, "FORWARD CURVE",    g_curve),
        (0, 1, "SEASONAL",         g_seasonal),
        (1, 1, "FORECAST VINTAGE", g_vintage),
    ]
    for col, row, name, fn in cells:
        gx0, gx1 = colX[col]
        rtop, rbot = rows[row]
        s += clabel(gx0, rtop + LABEL_DY, name)
        bb = (gx0, rtop + GLYPH_TOP, gx1, rbot - GLYPH_BOT_MARGIN)
        s += fn(bb)
    return wrap(s)

out = "/mnt/user-data/outputs/subtle-placeholders"
os.makedirs(out, exist_ok=True)
open(f"{out}/placeholder-energy-quadrant.svg","w").write(energy_quadrant())

# quick symmetry report
UTOP,UBOT,DY=14,346,180
for label,(rt,rb) in {"TOP":(14,180),"BOTTOM":(180,346)}.items():
    lbl=rt+30; gtop=rt+46; gbot=rb-22
    print(f"{label}: band[{rt},{rb}] label_base={lbl} glyph[{gtop},{gbot}] "
          f"top_margin_to_glyph={gtop-rt} glyph_to_band_bottom={rb-gbot}")
print("written")
