import math, random, os

W, H = 640, 360
PAD_X, PAD_T, PAD_B = 28, 28, 32
X0, X1 = PAD_X, W - PAD_X
Y0, Y1 = PAD_T, H - PAD_B

def catmull(pts):
    if len(pts) < 3:
        return "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    d = f"M {pts[0][0]:.1f},{pts[0][1]:.1f} "
    for i in range(len(pts) - 1):
        p0 = pts[i-1] if i > 0 else pts[0]
        p1, p2 = pts[i], pts[i+1]
        p3 = pts[i+2] if i+2 < len(pts) else pts[-1]
        c1 = (p1[0]+(p2[0]-p0[0])/6, p1[1]+(p2[1]-p0[1])/6)
        c2 = (p2[0]-(p3[0]-p1[0])/6, p2[1]-(p3[1]-p1[1])/6)
        d += f"C {c1[0]:.1f},{c1[1]:.1f} {c2[0]:.1f},{c2[1]:.1f} {p2[0]:.1f},{p2[1]:.1f} "
    return d

def frame():
    """Quiet placeholder container: faint fill + dashed border + a few gridlines."""
    s  = f'<rect x="4" y="4" width="{W-8}" height="{H-8}" rx="14" fill="currentColor" fill-opacity="0.022"/>'
    s += f'<rect x="4.5" y="4.5" width="{W-9}" height="{H-9}" rx="13.5" fill="none" stroke="currentColor" stroke-opacity="0.14" stroke-width="1" stroke-dasharray="5 5"/>'
    for i in range(1, 4):
        gy = Y0 + (Y1 - Y0) * i / 4
        s += f'<line x1="{X0}" y1="{gy:.1f}" x2="{X1}" y2="{gy:.1f}" stroke="currentColor" stroke-opacity="0.06"/>'
    return s

def wrap(inner, color="#94a3b8"):
    # `color` sets a sensible default; a parent CSS `color:` overrides it.
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
            f'width="{W}" height="{H}" fill="none" role="img" '
            f'aria-label="Chart placeholder" style="color:{color}">{inner}</svg>')

# ---------- 1) line / area silhouette ----------
def line_svg():
    n = 46
    random.seed(9); v = 0.42; raw = []
    for i in range(n):
        v += 0.006 + random.uniform(-0.045, 0.045)
        v = max(0.12, min(0.88, v)); raw.append(v)
    pts = [(X0 + (X1-X0)*i/(n-1), Y1 - (Y1-Y0)*val) for i, val in enumerate(raw)]
    line = catmull(pts)
    area = line + f" L {X1},{Y1} L {X0},{Y1} Z"
    s  = frame()
    s += ('<defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1">'
          '<stop offset="0" stop-color="currentColor" stop-opacity="0.14"/>'
          '<stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>')
    s += f'<path d="{area}" fill="url(#lg)"/>'
    s += f'<path d="{line}" fill="none" stroke="currentColor" stroke-opacity="0.46" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
    return wrap(s)

# ---------- 2) candlestick silhouette (monochrome) ----------
def candles_svg():
    n = 22
    random.seed(4); price = 0.45; data = []
    for i in range(n):
        o = price
        c = max(0.16, min(0.84, o + 0.004 + random.uniform(-0.05, 0.05)))
        hi = min(0.9, max(o, c) + random.uniform(0.02, 0.06))
        lo = max(0.1, min(o, c) - random.uniform(0.02, 0.06))
        data.append((o, hi, lo, c)); price = c
    def Y(val): return Y1 - (Y1-Y0)*val
    slot = (X1-X0)/n; bw = slot*0.5
    s = frame()
    for i, (o, hi, lo, c) in enumerate(data):
        cx = X0 + slot*i + slot/2
        top = Y(max(o, c)); bot = Y(min(o, c)); h = max(3, bot-top)
        s += f'<line x1="{cx:.1f}" y1="{Y(hi):.1f}" x2="{cx:.1f}" y2="{Y(lo):.1f}" stroke="currentColor" stroke-opacity="0.22" stroke-width="1.5"/>'
        s += f'<rect x="{cx-bw/2:.1f}" y="{top:.1f}" width="{bw:.1f}" height="{h:.1f}" rx="1.5" fill="currentColor" fill-opacity="0.28"/>'
    return wrap(s)

# ---------- 3) bars silhouette ----------
def bars_svg():
    n = 14
    random.seed(15)
    s = frame()
    slot = (X1-X0)/n; bw = slot*0.52
    for i in range(n):
        val = 0.25 + 0.6*abs(math.sin(i*0.7)) * random.uniform(0.6, 1.0)
        val = min(0.9, val)
        bh = (Y1-Y0)*val
        cx = X0 + slot*i + slot/2
        s += f'<rect x="{cx-bw/2:.1f}" y="{Y1-bh:.1f}" width="{bw:.1f}" height="{bh:.1f}" rx="2.5" fill="currentColor" fill-opacity="0.24"/>'
    return wrap(s)

out = "/mnt/user-data/outputs/subtle-placeholders"
os.makedirs(out, exist_ok=True)
open(f"{out}/placeholder-line.svg", "w").write(line_svg())
open(f"{out}/placeholder-candles.svg", "w").write(candles_svg())
open(f"{out}/placeholder-bars.svg", "w").write(bars_svg())
print("written")
